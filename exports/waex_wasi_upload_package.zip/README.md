# WASI Upload Package

This folder contains the umbrella `WAEX` family package for `WASI Intelligence`.

## Files

- `waex_family_characteristics.json`
  - Primary machine-readable family profile
- `waex_family_characteristics.md`
  - Human-readable family summary

## Recommended Upload Order

1. Upload `waex_family_characteristics.json`
2. Upload country packages after the family layer:
   - `CIREX`
   - `BUREX`

## Important Notes

- `WAEX` is the umbrella family, not a single country fund
- `CIREX` and `BUREX` are member funds inside the family
- The family exists to keep naming, governance language, and upload structure aligned across countries
