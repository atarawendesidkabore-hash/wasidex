# WASI Upload Package

This folder contains a generic `BUREX` fund upload package prepared for `WASI Intelligence`.

## Files

- `burex_fund_characteristics.json`
  - Primary machine-readable upload file
- `burex_fund_characteristics.md`
  - Human-readable summary of the same profile

## Recommended Upload Order

1. Upload `burex_fund_characteristics.json`
2. If the platform supports notes or attachments, also upload `burex_fund_characteristics.md`

## Important Notes

- This package is prepared as a generic profile because a public `WASI Intelligence` import schema could not be verified.
- `BUREX Fund` is described as a `proposed_pre_launch` vehicle, not as a live regulated fund.
- `BUREX` now sits inside the `WAEX` family as the landlocked-corridor member.
- Burkina Faso is landlocked, so the benchmark is framed around outbound export tonnage across all transport modes.
- The package explicitly incorporates corridor and trade relationships with `Ghana`, `Togo`, `Benin`, `Cote d'Ivoire`, `Mali`, and `Niger`.
- Illustrative constituent weights are prototype values and should be replaced with official twenty-year export-tonnage data before institutional launch.

## If WASI Requires Specific Fields

If `WASI Intelligence` shows a required template, schema, or import error, map the fields from the JSON file into that structure and keep:

- fund identity
- objective
- benchmark methodology
- constituent universe
- risks
- regulatory positioning
- technology layer
